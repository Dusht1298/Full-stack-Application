import React, { useState , useEffect} from "react";
import axios from 'axios';
import {useNavigate, useParams} from "react-router-dom";

const EditUser = () => {
    const navigate = useNavigate();
    const { Id } = useParams();

    const [user, setUser] = useState({
        id: "",
        name: "",
        address: "",
        contact: ""
    });

    const { id, name, address, contact } = user;

    const onInputChange = e => {
        setUser({ ...user, [e.target.name]: e.target.value })
    }

    const onSubmit = async e => {
        e.preventDefault();
        await axios.put("http://localhost:8081/demo/update", user);
        navigate('/');
    }

    useEffect(() =>{
        loadUser();
    }, [])

    const loadUser = async () =>{
        const result = await axios.get("http://localhost:8081/demo/get/" + Id);
        setUser(result.data);
    }

    return (

        <form onSubmit={e => onSubmit(e)}>
            <center><h1>Update User</h1></center> <br />
            <div className="form-group row">
                <label for="inputid" className="col-sm-1 col-form-label">UserId</label>
                <div className="col-sm-10">
                    <input className="form-control" value={id} readonly/>
                </div>
            </div>
            <div className="form-group row">
                <label for="inputName" className="col-sm-1 col-form-label">Name</label>
                <div className="col-sm-10">
                    <input type="text" className="form-control" name="name" placeholder="Enter Name" value={name} onChange={e => onInputChange(e)} />
                </div>
            </div>
            <div className="form-group row">
                <label for="inputAddress" className="col-sm-1 col-form-label">Address</label>
                <div className="col-sm-10">
                    <input type="text" className="form-control" name="address" placeholder="Enter Address" value={address} onChange={e => onInputChange(e)} />
                </div>
            </div>
            <div className="form-group row">
                <label for="inputContact" className="col-sm-1 col-form-label">Contact</label>
                <div className="col-sm-10">
                    <input type="tel" className="form-control" name="contact" placeholder="Enter Contact" value={contact} onChange={e => onInputChange(e)} />
                </div>
            </div>

            <div className="form-group row">
                <div className="col-sm-10">
                    <button type="submit" className="btn btn-warning">Update</button>
                </div>
            </div>
        </form>
    )
}

export default EditUser;