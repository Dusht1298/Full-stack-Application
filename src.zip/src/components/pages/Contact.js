import React from "react";

const Contact = () => {
    return (
        <div className="container">
            <div className="py-4">
                
                <form>
                    <div className="mb-3">
                        <label for="exampleInputSubject" className="form-label">Subject</label>
                        <input type="text" className="form-control" id="exampleInputSubject" aria-describedby="emailHelp" />
                    </div>
                    <div className="mb-3">
                        <label for="exampleInputDescription" className="form-label">Description</label>
                        <input type="text" className="form-control" id="exampleInputDescription" />
                    </div>
                    <div className="mb-3 form-check">
                        <input type="checkbox" className="form-check-input" id="exampleCheck1" />
                            <label className="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    )
}

export default Contact;