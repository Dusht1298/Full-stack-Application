import React from "react";

const About = () => {
    return (
        <div className="container">
            <div className="py-4">
                <h1>Datacard AIS Team!</h1>
                <br/><br/>
                <h4>Dev -  Sumit Neha Aman Palak Naveen Sanjay Shubham Dushyant Anuj Anurag Santanu.</h4>
                <h4>QA -  Ankit Sajal Abhay Ravi Emon Gourab.</h4>
            </div>
        </div>
    )
}

export default About;