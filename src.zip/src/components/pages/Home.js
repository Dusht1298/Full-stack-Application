import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { Button } from '@mui/material'

const Home = () => {

    const [users, setUser] = useState([]);

    useEffect(() => {
        loadUsers();
    }, []);

    const loadUsers = async () => {
        const result = await axios.get("http://localhost:8081/demo/getAll");
        setUser(result.data);
    };

    const deleteUser = async id => {
        await axios.delete("http://localhost:8081/demo/del/" + id);
        loadUsers();
    }

    return (
        <div className="container">
            <div className="py-4">
                <h1>Home page</h1> <br />
                <table className="table">
                    <thead className="table-dark">
                        <tr>
                            <th scope="col">UserId</th>
                            <th scope="col">Name</th>
                            <th scope="col">Address</th>
                            <th scope="col">Contact</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            users.map((user) => (
                                <tr>
                                    <td>{user.id}</td>
                                    <td>{user.name}</td>
                                    <td>{user.address}</td>
                                    <td>{user.contact}</td>
                                    <td>
                                        <Link className="btn btn-primary" to={`/users/get/${user.id}`}>Edit</Link>
                                        <Link className="btn btn-danger" onClick={() => deleteUser(user.id)} to="/">Delete</Link>
                                    </td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table>

            </div>
        </div>
    )
}

export default Home;

